import { TransactionContext } from "../context/TransactionContext";
import React, { useContext } from "react";
import axios from "axios";
import Connect from "./Connect";

function Homepage() {
  
  return (
    <div className="App">
      <div className="flex flex-row justify-around">
      </div>
    </div>
  );
}

export default Homepage;
